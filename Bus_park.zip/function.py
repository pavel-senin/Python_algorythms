

def read_data_from_file(name):
    result = []
    with open(name, 'r', encoding='utf8') as datafile:
        for line in datafile:
            result.append(line.strip('\n').split(','))
        datafile.close()
        return result

def print_bus(name):
    print(read_data_from_file(name))
    return

def add_bus(name):
    id = str(input ('Введите ID автобуса: '))
    number = str(input ('Введите номер автобуса: '))
    with open(name, 'a', encoding='utf8') as datafile:
        datafile.writelines('\n')
        datafile.writelines(id+', '+number)
        print('Автобус добавлен')
    return

def print_driver(name):
    print(read_data_from_file(name))
    return

def add_driver(name):
    id = str(input ('Введите ID водителя: '))
    drname = str(input ('Введите имя водителя: '))
    with open(name, 'a', encoding='utf8') as datafile:
        datafile.writelines('\n')
        datafile.writelines(id+', '+drname)
        print('Водитель добавлен')
    return

def print_route(name):
    print(read_data_from_file(name))
    return

def add_route(name3):
    idroute = str(input ('Введите ID маршрута: '))
    idbus = str(input ('Введите ID автобуса: '))
    iddr = str(input ('Введите ID водителя: '))
    with open(name3, 'a', encoding='utf8') as datafile:
        datafile.writelines('\n')
        datafile.writelines(idroute+', '+idbus+', '+iddr)
        print('Маршрут добавлен')
    return
