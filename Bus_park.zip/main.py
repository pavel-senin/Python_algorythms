from menu import Menu
import function as fn

name1 = 'bus.txt'
name2 = 'driver.txt'
name3 = 'route.txt'




if __name__== "__main__":
    menuItems = [
        ("1", "Вывод автобусов", fn.print_bus),
        ("2", "Добавление автобусов", fn.add_bus),
        ("3", "Вывод водителей", fn.print_driver),
        ("4", "Добавление водителей", fn.add_driver),
        ("5", "Вывод маршрута", fn.print_route),
        ("6", "Добавление маршрута", fn.add_route),
        ("7", "Выход", lambda: exit())]

menu = Menu(menuItems)

command = 0

while (command!=7):
    print('Введите номер действия:')
    print('1 - Вывод автобусов')
    print('2 - Добавление автобусов')
    print('3 - Вывод водителей')
    print('4 - Добавление водителей')
    print('5 - Вывод маршрута')
    print('6 - Добавление маршрута')
    print('7 - Выход')
    command = input("Ввод команды: ")
    command = int(command)
    if command == 7:
        print('Выход')
        break
    elif command == 1:
        print('Вывод автобусов')
        fn.print_bus(name1)
    elif command == 2:
        print('Добавление автобуса')
        fn.add_bus(name1)
    elif command == 3:
        print('Вывод водителей')
        fn.print_driver(name2)
    elif command == 4:
        print('Добавить водителя: ')
        fn.add_driver(name2)
    elif command == 5:
        print('Вывод маршрутов: ')
        fn.print_route(name3)
    elif command == 6:
        print('Добавить маршрут: ')
        fn.add_route(name3)